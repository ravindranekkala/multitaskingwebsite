# U-RESTAURANT | RESTAURANT WEBSITE

Ini adalah sebuah template website untuk platform restoran yang dibuat dengan menggunakan teknologo _HTML_, _CSS_, dan _JavaScript_.

# Tampilan Website

![u-restaurant](u-restaurant.png)